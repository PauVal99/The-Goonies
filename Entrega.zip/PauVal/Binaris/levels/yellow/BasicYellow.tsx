<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="BasicYellow" tilewidth="8" tileheight="8" tilecount="66" columns="11">
 <image source="../../images/yellow/Yellow.png" width="88" height="48"/>
</tileset>
